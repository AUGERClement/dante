/*
** astar.h for dante in /home/yami/dante/astar2/include/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Sun May 14 21:58:43 2017 Delphine Godet
** Last update Sun May 14 22:28:50 2017 Delphine Godet
*/

#ifndef ASTAR_H
# define ASTAR_H

# define WALL 'X'
# define VISITED '-'
# define SOL 'o'
# define PATH '*'

typedef struct		s_queue
{
  int			x;
  int			y;
  double		size;
  struct s_queue	*next;
}			t_queue;

typedef	struct	s_info
{
  char		**maze;
  int		**cells;
  int		width;
  int		height;
}		t_info;

t_info		load_maze(char *filename);
double		calc_dist(int x1, int x2, int width, int height);
t_info		astar(t_info info);
void		rewrite_map(t_info *info);
void		print_maze(char **maze);

#endif

/*
** graphical_printing.c for dante in /home/yami/dante/bonus/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Sat May 13 23:16:17 2017 Delphine Godet
** Last update Wed May 17 14:42:23 2017 Delphine Godet
*/

#define WIDTH	2000
#define HEIGHT	1600

#include <stdlib.h>
#include <SFML/Graphics.h>

#include "astar.h"

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

t_my_framebuffer        *my_framebuffer_create(sfVideoMode mode);
char		**keep_window_open(sfRenderWindow *window, sfTexture *texture, sfSprite *sprite, t_my_framebuffer *buffer, t_info info, int size);
void	draw_maze(char **maze, t_my_framebuffer *framebuf, int size);

int	calc_squares_size(int wid, int hei)
{
  int	size;

  if (wid > hei)
    {
      if (WIDTH < HEIGHT)
	size = WIDTH / (wid * 2);
      else
	size = HEIGHT / (wid * 2);
    }
  else
    {
      if (WIDTH < HEIGHT)
	size = WIDTH / (hei * 2);
      else
	size = HEIGHT / (hei * 2);
    }
  return (size);
}

char			**print_maze_graphical(t_info info)
{
  sfVideoMode		mode;
  sfRenderWindow	*win;
  sfTexture		*texture;
  sfSprite		*sprite;
  t_my_framebuffer	*framebuf;
  int			size;

  mode.width = WIDTH;
  mode.height = HEIGHT;
  mode.bitsPerPixel = 32;
  win = sfRenderWindow_create(mode, "dante", sfResize | sfClose, NULL);
  if (win == NULL)
    exit(84);
  sprite = sfSprite_create();
  texture = sfTexture_create(WIDTH, HEIGHT);
  framebuf = my_framebuffer_create(mode);
  sfSprite_setTexture(sprite, texture, sfTrue);
  size = calc_squares_size(info.width, info.height);
  draw_maze(info.maze, framebuf, size);
  sfTexture_updateFromPixels(texture, framebuf->pixels, WIDTH, HEIGHT, 0, 0);
  info.maze = keep_window_open(win, texture, sprite, framebuf, info, size);
  sfSprite_destroy(sprite);
  sfTexture_destroy(texture);
  sfRenderWindow_destroy(win);
  return (info.maze);
}

/*
** breadth_first_search.c for dante in /home/yami/dante/largeur/srcs/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Thu May 11 23:17:49 2017 Delphine Godet
** Last update Wed May 17 14:50:17 2017 Delphine Godet
*/

#include <stdio.h>
#include <stdlib.h>

#include "astar.h"
#include "my.h"

t_queue		*add_to_queue(t_queue *queue, int x, int y, t_info *info)
{
  t_queue	*new;
  t_queue	*end;

  new = xmalloc(sizeof(*queue), 1);
  new->x = x;
  new->y = y;
  new->size = calc_dist(x, y, info->width, info->height);
  new->next = NULL;
  end = queue;
  while (end->next != NULL)
    end = end->next;
  end->next = new;
  return (queue);
}

t_queue		*del_from_queue(t_queue *head, t_queue *queue)
{
  t_queue	*tmp;
  t_queue 	*tmp2;

  tmp = head;
  if (head == queue)
    {
      head = head->next;
      free(tmp);
    }
  else
    {
      while (tmp->next != NULL && tmp->next != queue)
	tmp = tmp->next;
      if (tmp->next == queue && queue != NULL)
	{
	  tmp2 = tmp->next;
	  tmp->next = tmp->next->next;
	  free(tmp2);
	}
    }
  return (head);
}

/*t_queue	*mark_bread(t_queue *queue, t_info *info)
{
  info->maze[queue->y][queue->x] = '-';
  if (info->maze[queue->y][queue->x + 1] != '\0' &&
      info->cells[queue->y][queue->x + 1] == 0)
    {
      info->cells[queue->y][queue->x + 1] =
	  info->cells[queue->y][queue->x] + 1;
      add_to_queue(queue, queue->x + 1, queue->y, info);
    }
  if (queue->x > 0 && info->cells[queue->y][queue->x - 1] == 0)
    {
      info->cells[queue->y][queue->x - 1] =
	  info->cells[queue->y][queue->x] + 1;
      add_to_queue(queue, queue->x - 1, queue->y, info);
    }
  if (info->maze[queue->y + 1] != NULL &&
      info->cells[queue->y + 1][queue->x] == 0)
    {
      info->cells[queue->y + 1][queue->x] =
	  info->cells[queue->y][queue->x] + 1;
      add_to_queue(queue, queue->x, queue->y + 1, info);
    }
  return (queue);
}*/

t_queue		*find_shortest(t_queue *head)
{
  t_queue	*tmp;
  double	min;

  tmp = head;
  if (head != NULL)
    {
      tmp = head->next;
      min = head->size;
      while (tmp != NULL)
	{
	  if (tmp->size < min)
	    min = tmp->size;
	  tmp = tmp->next;
	}
      tmp = head;
      while (tmp->size != min)
	tmp = tmp->next;
      return (tmp);
  }
  return (NULL);
}

/*t_info		astar(t_info info)
{
  t_queue	*head;
  t_queue	*queue;

  queue = xmalloc(sizeof(*queue), 1);
  queue->x = queue->y = 0;
  queue->size = calc_dist(queue->x, queue->y, info.width, info.height);
  queue->next = NULL;
  head = queue;
  while (head != NULL && (queue->x != info.width - 1 ||
	  queue->y != info.height))
    {
      queue = mark_bread(queue, &info);
      if (queue->y > 0 && info.cells[queue->y - 1][queue->x] == 0)
          {
            info.cells[queue->y - 1][queue->x] =
                info.cells[queue->y][queue->x] + 1;
            add_to_queue(queue, queue->x, queue->y - 1, &info);
          }
      head = del_from_queue(head, queue);
      queue = find_shortest(head);
    }
  return (info);
}*/

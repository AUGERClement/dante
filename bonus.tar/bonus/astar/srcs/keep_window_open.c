/*
** keep_window_open.c for emacs in /home/delphine.godet/wireframe/src
**
** Made by delphine godet
** Login   <delphine.godet@epitech.net>
**
** Started on  Mon Nov 21 12:50:19 2016 delphine godet
** Last update Wed May 17 14:55:35 2017 Delphine Godet
*/

#include <stdio.h>
#include <SFML/Graphics.h>

#include "my.h"
#include "astar.h"

#define WIDTH	2000
#define HEIGHT	1600

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

void    my_put_square(unsigned int x, unsigned int y, sfColor color,
		      t_my_framebuffer *framebuffer, unsigned int size);

void	draw_maze(char **maze, t_my_framebuffer *framebuf, int size)
{
  int i;
  int j;
  int k;
  int l;

  i = j = k = l = 0;
  while (maze[i] != NULL)
    {
      j = l = 0;
      while (maze[i][j] != '\0')
	{
	  if (maze[i][j] == 'o')
	    my_put_square(l, k, sfMagenta, framebuf, size);
	  else if (i == 0 && j == 0)
	    my_put_square(l, k, sfGreen, framebuf, size);
	  else if (maze[i + 1] == NULL && maze[i][j + 1] == '\0')
	    my_put_square(l, k, sfRed, framebuf, size);
	  else if (maze[i][j] == '-')
	    my_put_square(l, k, sfCyan, framebuf, size);
	  else if (maze[i][j] == '*')
	    my_put_square(l, k, sfWhite, framebuf, size);
	  else
	    my_put_square(l, k, sfBlue, framebuf, size);
	  l += size + 1;
	  j++;
	}
      i++;
      k += size + 1;
    }
}

t_queue		*find_shortest(t_queue *head);
t_queue		*add_to_queue(t_queue *queue, int x, int y, t_info *info);
t_queue		*del_from_queue(t_queue *head, t_queue *queue);

t_queue	*mark_bread(t_queue *queue, t_info *info, t_my_framebuffer *buffer, int size)
{
  info->maze[queue->y][queue->x] = '-';
  if (info->maze[queue->y][queue->x + 1] != '\0' &&
      info->cells[queue->y][queue->x + 1] == 0)
    {
      info->cells[queue->y][queue->x + 1] =
      info->cells[queue->y][queue->x] + 1;
      add_to_queue(queue, queue->x + 1, queue->y, info);
      my_put_square((queue->x + 1) * size + queue->x, queue->y * size + queue->y, sfCyan, buffer, size);
    }
  if (queue->x > 0 && info->cells[queue->y][queue->x - 1] == 0)
    {
      info->cells[queue->y][queue->x - 1] =
      info->cells[queue->y][queue->x] + 1;
      add_to_queue(queue, queue->x - 1, queue->y, info);
      my_put_square((queue->x - 1) * size + queue->x, queue->y * size + queue->y, sfCyan, buffer, size);
    }
  if (info->maze[queue->y + 1] != NULL &&
      info->cells[queue->y + 1][queue->x] == 0)
    {
      info->cells[queue->y + 1][queue->x] =
      info->cells[queue->y][queue->x] + 1;
      add_to_queue(queue, queue->x, queue->y + 1, info);
      my_put_square(queue->x * size + queue->x, (queue->y + 1) * size + queue->y, sfCyan, buffer, size);
    }
  if (queue->y > 0 && info->cells[queue->y - 1][queue->x] == 0)
    {
      info->cells[queue->y - 1][queue->x] = info->cells[queue->y][queue->x] + 1;
      add_to_queue(queue, queue->x, queue->y - 1, info);
      my_put_square(queue->x * size + queue->x, (queue->y - 1) * size + queue->y, sfCyan, buffer, size + 1);
    }
  return (queue);
}

t_queue		*find_the_way(t_info *info)
{
  t_queue	*way;
  t_queue	*tmp;

  tmp = xmalloc(sizeof(*tmp), 1);
  tmp->x = info->width - 1;
  tmp->y = info->height - 1;
  tmp->next = NULL;
  way = tmp;
  while (way->x != 0 || way->y != 0)
    {
      if (tmp->y > 0 && info->cells[tmp->y - 1][tmp->x] == info->cells[tmp->y][tmp->x] - 1)
	{
	  tmp = xmalloc(sizeof(*tmp), 1);
	  tmp->x = way->x;
	  tmp->y = way->y - 1;
	  tmp->next = way;
	  way = tmp;
	}
      else if (info->maze[tmp->y + 1] != NULL &&
	       info->cells[tmp->y + 1][tmp->x] == info->cells[tmp->y][tmp->x] - 1)
	{
	  tmp = xmalloc(sizeof(*tmp), 1);
	  tmp->x = way->x;
	  tmp->y = way->y + 1;
	  tmp->next = way;
	  way = tmp;
	}
      else if (tmp->x > 0 && info->cells[tmp->y][tmp->x - 1] == info->cells[tmp->y][tmp->x] - 1)
	{
	  tmp = xmalloc(sizeof(*tmp), 1);
	  tmp->x = way->x - 1;
	  tmp->y = way->y;
	  tmp->next = way;
	  way = tmp;
	}
      else if (info->maze[tmp->y][tmp->x + 1] != '\0' &&
	       info->cells[tmp->y][tmp->x + 1] == info->cells[tmp->y][tmp->x] - 1)
	{
	  tmp = xmalloc(sizeof(*tmp), 1);
	  tmp->x = way->x + 1;
	  tmp->y = way->y;
	  tmp->next = way;
	  way = tmp;
	}
    }
  return (way);
}

char		**keep_window_open(sfRenderWindow *window, sfTexture *texture, sfSprite *sprite,
				   t_my_framebuffer *buffer, t_info info, int size)
{
  t_queue	*queue;
  t_queue	*head;
  t_queue	*way;
  t_queue	*tmp;
  sfEvent	event;
  size_t	i;
  size_t	j;

  i = j = 0;
  queue = xmalloc(sizeof(*queue), 1);
  queue->x = queue->y = 0;
  queue->size = calc_dist(queue->x, queue->y, info.width, info.height);
  queue->next = NULL;
  head = queue;
  while (sfRenderWindow_isOpen(window))
    {
      if (head != NULL && (queue->x != info.width - 1 || queue->y != info.height - 1))
	{
	  sfRenderWindow_clear(window, sfBlack);
          queue = mark_bread(queue, &info, buffer, size);
	  head = del_from_queue(head, queue);
	  queue = find_shortest(head);
          sfTexture_updateFromPixels(texture, buffer->pixels,
                  buffer->width, buffer->height, 0, 0);
	}
      if (queue->x == info.width - 1 && queue->y == info.height - 1)
	{
	  way = find_the_way(&info);
	  tmp = way;
	  j = 0;
	  while (j < i)
	    {
	      tmp = tmp->next;
	      j++;
	    }
	  if (tmp != NULL)
	    {
	      sfRenderWindow_clear(window, sfBlack);
	      my_put_square(tmp->x * size + tmp->x, tmp->y * size + tmp->y, sfMagenta, buffer, size);
	      sfTexture_updateFromPixels(texture, buffer->pixels,
					 buffer->width, buffer->height, 0, 0);
	      i++;
	    }
	}
      while (sfRenderWindow_pollEvent(window, &event))
	{
	  if (event.type == sfEvtKeyPressed && event.key.code == sfKeyEscape)
	    sfRenderWindow_close(window);
	  if (event.type == sfEvtClosed)
	    sfRenderWindow_close(window);
	}
      sfRenderWindow_clear(window, sfBlack);
      sfRenderWindow_drawSprite(window, sprite, NULL);
      sfRenderWindow_display(window);
    }
  return (info.maze);
}

/*
** my_put_square.c for emacs in /home/delphine.godet/graph_prog
**
** Made by delphine godet
** Login   <delphine.godet@epitech.net>
**
** Started on  Mon Nov 14 17:03:23 2016 delphine godet
** Last update Sat May 13 23:42:11 2017 Delphine Godet
*/

#include <SFML/Graphics.h>

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

void    my_put_pixel(t_my_framebuffer *framebuffer, int x, int y,
		     sfColor color);

void    my_put_square(unsigned int x, unsigned int y,
		      sfColor color, t_my_framebuffer *framebuffer,
		      unsigned int size)
{
  unsigned int  tmp;
  unsigned int  tmp2;

  tmp = x + size;
  tmp2 = y + size;
  while (x <= tmp)
    {
      while (y <= tmp2)
	{
	  my_put_pixel(framebuffer, x, y, color);
	  y++;
	}
      y = tmp2 - size;
      x++;
    }
}

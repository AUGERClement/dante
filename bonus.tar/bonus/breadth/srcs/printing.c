/*
** printing.c for dante in /home/yami/dante/largeur/srcs/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Thu May 11 23:17:44 2017 Delphine Godet
** Last update Sat May 13 19:57:58 2017 Delphine Godet
*/

#include <stdio.h>

#include "breadth.h"
#include "my.h"

void		rewrite_map(t_info *info)
{
  size_t	i;
  size_t	j;

  i = info->height - 1;
  j = info->width - 1;
  info->maze[0][0] = 'o';
  while (i != 0 || j != 0)
    {
      info->maze[i][j] = 'o';
      if (i > 0 && info->cells[i - 1][j] == info->cells[i][j] - 1)
	i = i - 1;
      else if (info->maze[i + 1] != NULL &&
	       info->cells[i + 1][j] == info->cells[i][j] - 1)
	i = i + 1;
      else if (j > 0 && info->cells[i][j - 1] == info->cells[i][j] - 1)
	j = j - 1;
      else if (info->maze[i][j + 1] != '\0' &&
	       info->cells[i][j + 1] == info->cells[i][j] - 1)
	j = j + 1;
      else
	{
	  free_tab(info->maze);
	  return ;
	}
    }
}

void		print_maze(char **maze)
{
  size_t	i;
  size_t	j;

  i = j = 0;
  while (maze[i] != NULL)
    {
      j = 0;
      while (maze[i][j] != '\0')
	{
	  if (maze[i][j] == '-')
	    my_putchar('*');
	  else
	    my_putchar(maze[i][j]);
	  j++;
	}
      my_putchar('\n');
      i++;
    }
}

void	debug(char **maze)
{
  int i = 0;
  while (maze[i] != NULL)
    printf("%s\n", maze[i++]);
}

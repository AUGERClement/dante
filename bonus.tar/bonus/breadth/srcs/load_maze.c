/*
** load_maze.c for dante in /home/yami/dante/depth/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Thu May 11 01:25:16 2017 Delphine Godet
** Last update Sat May 13 20:11:05 2017 Delphine Godet
*/

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

#include "breadth.h"
#include "my.h"

int	**place_walls(char **maze, int width, int height)
{
  int	**bfs;
  int	i;
  int	j;

  bfs = xmalloc(sizeof(int *), height + 1);
  i = 0;
  while (maze[i] != NULL)
    {
      j = 0;
      bfs[i] = xmalloc(sizeof(int), width);
      while (maze[i][j] != '\0')
	{
	  if (maze[i][j] == 'X')
	    bfs[i][j] = -1;
	  else
	    bfs[i][j] = 0;
	  j++;
	}
      i++;
    }
  bfs[i] = NULL;
  return (bfs);
}

t_info		load_maze(char *filename)
{
  t_info	info;
  int		fd;
  size_t	i;

  fd = open(filename, O_RDONLY);
  if (fd < 0)
    {
      info.maze = NULL;
      return (info);
    }
  info.maze = xmalloc(sizeof(char *), 2);
  i = 0;
  while ((info.maze[i] = get_next_line(fd)) != NULL)
    {
      i++;
      info.maze = realloc(info.maze, sizeof(char *) * (i + 2));
      if (info.maze == NULL)
	return (info);
    }
  info.maze[i] = NULL;
  close(fd);
  info.height = i;
  info.width = my_strlen(info.maze[0]);
  info.cells = place_walls(info.maze, info.width, info.height);
  return (info);
}

/*
** my_put_pixel.c for emacs in /home/delphine.godet/wireframe/src
**
** Made by delphine godet
** Login   <delphine.godet@epitech.net>
**
** Started on  Fri Nov 18 19:22:32 2016 delphine godet
** Last update Mon May 15 23:30:03 2017 Delphine Godet
*/

#include <SFML/Graphics.h>

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

void    my_put_pixel(t_my_framebuffer *framebuffer, int x, int y,
		     sfColor color)
{
  framebuffer->pixels[(framebuffer->width * y + x) * 4] = color.r;
  framebuffer->pixels[(framebuffer->width * y + x) * 4 + 1] = color.g;
  framebuffer->pixels[(framebuffer->width * y + x) * 4 + 2] = color.b;
  framebuffer->pixels[(framebuffer->width * y + x) * 4 + 3] = color.a;
}

/*
** keep_window_open.c for emacs in /home/delphine.godet/wireframe/src
**
** Made by delphine godet
** Login   <delphine.godet@epitech.net>
**
** Started on  Mon Nov 21 12:50:19 2016 delphine godet
** Last update Wed May 17 19:28:15 2017 Delphine Godet
*/

#include <stdio.h>
#include <SFML/Graphics.h>
#include <stdlib.h>
#include "time.h"
#include "depth.h"

#define WIDTH	2000
#define HEIGHT	1600

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

void    my_put_square(unsigned int x, unsigned int y, sfColor color,
		      t_my_framebuffer *framebuffer, unsigned int size);

void	draw_maze(char **maze, t_my_framebuffer *framebuf, int size)
{
  int i;
  int j;
  int k;
  int l;

  i = j = k = l = 0;
  while (maze[i] != NULL)
    {
      j = l = 0;
      while (maze[i][j] != '\0')
	{
	  if (maze[i][j] == 'o')
	    my_put_square(l, k, sfMagenta, framebuf, size);
	  else if (i == 0 && j == 0)
	    my_put_square(l, k, sfGreen, framebuf, size);
	  else if (maze[i + 1] == NULL && maze[i][j + 1] == '\0')
	    my_put_square(l, k, sfRed, framebuf, size);
	  else if (maze[i][j] == '-')
	    my_put_square(l, k, sfCyan, framebuf, size);
	  else if (maze[i][j] == '*')
	    my_put_square(l, k, sfWhite, framebuf, size);
	  else
	    my_put_square(l, k, sfBlue, framebuf, size);
	  l += size + 1;
	  j++;
	}
      i++;
      k += size + 1;
    }
}

char		**keep_window_open(sfRenderWindow *window, sfTexture *texture, sfSprite *sprite,
				   t_my_framebuffer *buffer, char **maze, int size)
{
  size_t	x;
  size_t	y;
  sfEvent	event;

  x = y = 0;
  while (sfRenderWindow_isOpen(window))
    {
      if (maze[y + 1] != NULL || maze[y][x + 1] != '\0')
	{
	  sfRenderWindow_clear(window, sfBlack);
	  if (maze[y][x + 1] == '*')
	    {
	      maze[y][x + 1] = 'o';
	      my_put_square((x + 1) * size + x, y * size + y, sfMagenta, buffer, size);
	      x++;
	    }
	  else if (maze[y + 1] != NULL && maze[y + 1][x] == '*')
	    {
	      maze[y + 1][x] = 'o';
	      my_put_square(x * size + x, (y + 1) * size + y, sfMagenta, buffer, size);
	      y++;
	    }
	  else if (x > 0 && maze[y][x - 1] == '*')
	    {
	      maze[y][x - 1] = 'o';
	      my_put_square((x - 1) * size + x, y * size + y, sfMagenta, buffer, size);
	      x--;
	    }
	  else if (y > 0 && maze[y - 1][x] == '*')
	    {
	      maze[y - 1][x] = 'o';
	      my_put_square(x * size + x, (y - 1) * size + y, sfMagenta, buffer, size);
	      y--;
	    }
	  else
	    {
	      maze[y][x] = '-';
	      my_put_square(x * size + x, y * size + y, sfCyan, buffer, size);
	      if (y > 0 && maze[y - 1][x] == 'o')
		y--;
	      else if (x > 0 && maze[y][x - 1] == 'o')
		x--;
	      else if (maze[y + 1] != NULL && maze[y + 1][x] == 'o')
		y++;
	      else if (maze[y][x + 1] == 'o')
		x++;
	    }
	  sfTexture_updateFromPixels(texture, buffer->pixels,
				     buffer->width, buffer->height, 0, 0);
	}
      while (sfRenderWindow_pollEvent(window, &event))
	{
	  if (event.type == sfEvtKeyPressed && event.key.code == sfKeyEscape)
	    sfRenderWindow_close(window);
	  if (event.type == sfEvtClosed)
	    sfRenderWindow_close(window);
	}
      sfRenderWindow_clear(window, sfBlack);
      sfRenderWindow_drawSprite(window, sprite, NULL);
      sfRenderWindow_display(window);
    }
  return (maze);
}

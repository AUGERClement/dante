/*
** printing.c for dante in /home/yami/dante/depth/srcs/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Thu May 11 06:53:57 2017 Delphine Godet
** Last update Sun May 14 18:10:17 2017 Delphine Godet
*/

#include <unistd.h>

void		print_maze(char **maze)
{
  size_t	i;
  size_t	j;

  i = j = 0;
  while (maze[i] != NULL)
    {
      j = 0;
      while (maze[i][j] != '\0')
	{
	  write(1, &maze[i][j], 1);
	  j++;
	}
      write(1, "\n", 1);
      i++;
    }
}

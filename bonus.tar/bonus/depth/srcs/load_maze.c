/*
** load_maze.c for dante in /home/yami/dante/depth/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Thu May 11 01:25:16 2017 Delphine Godet
** Last update Thu May 11 09:46:24 2017 Delphine Godet
*/

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

#include "my.h"

char		**load_maze(char *filename)
{
  int		fd;
  char		**maze;
  size_t	i;

  fd = open(filename, O_RDONLY);
  if (fd < 0)
    return (NULL);
  maze = xmalloc(sizeof(char *), 2);
  i = 0;
  while ((maze[i] = get_next_line(fd)) != NULL)
    {
      i++;
      maze = realloc(maze, sizeof(char *) * (i + 2));
      if (maze == NULL)
	return (NULL);
    }
  maze[i] = NULL;
  close(fd);
  return (maze);
}

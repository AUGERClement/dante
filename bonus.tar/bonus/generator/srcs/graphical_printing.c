/*
** graphical_printing.c for dante in /home/yami/dante/bonus/
**
** Made by Delphine Godet
** Login   <delphine.godet@epitech.eu>
**
** Started on  Sat May 13 23:16:17 2017 Delphine Godet
** Last update Mon May 15 01:09:06 2017 Delphine Godet
*/

#define WIDTH	2000
#define HEIGHT	1600

#include <stdlib.h>
#include <SFML/Graphics.h>

#include "generator.h"

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

t_my_framebuffer        *my_framebuffer_create(sfVideoMode mode);
char		**keep_window_open(sfRenderWindow *window, sfTexture *texture, sfSprite *sprite, t_my_framebuffer *buffer, char **maze, t_cell *cells, int size);
void	draw_maze(char **maze, t_my_framebuffer *framebuf, int size);

int	calc_squares_size(int wid, int hei)
{
  int	size;

  if (wid > hei)
    {
      if (WIDTH < HEIGHT)
	size = WIDTH / (wid * 2);
      else
	size = HEIGHT / (wid * 2);
    }
  else
    {
      if (WIDTH < HEIGHT)
	size = WIDTH / (hei * 2);
      else
	size = HEIGHT / (hei * 2);
    }
  return (size);
}

char			**print_maze_graphical(char **maze, t_args *args, t_cell *cells)
{
  sfVideoMode		mode;
  sfRenderWindow	*win;
  sfTexture		*texture;
  sfSprite		*sprite;
  t_my_framebuffer	*framebuf;
  int			size;

//  maze = select_bias_fcts(maze, cells, args);
  mode.width = WIDTH;
  mode.height = HEIGHT;
  mode.bitsPerPixel = 32;
  win = sfRenderWindow_create(mode, "dante", sfResize | sfClose, NULL);
  if (win == NULL)
    exit(84);
  sprite = sfSprite_create();
  texture = sfTexture_create(WIDTH, HEIGHT);
  framebuf = my_framebuffer_create(mode);
  sfSprite_setTexture(sprite, texture, sfTrue);
  size = calc_squares_size(args->width, args->height);
  draw_maze(maze, framebuf, size);
  sfTexture_updateFromPixels(texture, framebuf->pixels, WIDTH, HEIGHT, 0, 0);
  maze = keep_window_open(win, texture, sprite, framebuf, maze, cells, size);
  sfSprite_destroy(sprite);
  sfTexture_destroy(texture);
  sfRenderWindow_destroy(win);
  return (maze);
}

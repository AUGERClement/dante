/*
** keep_window_open.c for emacs in /home/delphine.godet/wireframe/src
**
** Made by delphine godet
** Login   <delphine.godet@epitech.net>
**
** Started on  Mon Nov 21 12:50:19 2016 delphine godet
** Last update Mon May 15 23:07:27 2017 Delphine Godet
*/

#include <stdio.h>
#include <SFML/Graphics.h>
#include <stdlib.h>
#include "time.h"
#include "generator.h"

#define WIDTH	2000
#define HEIGHT	1600

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

void    my_put_square(unsigned int x, unsigned int y, sfColor color,
		      t_my_framebuffer *framebuffer, unsigned int size);

void	draw_maze(char **maze, t_my_framebuffer *framebuf, int size)
{
  int i;
  int j;
  int k;
  int l;

  i = j = k = l = 0;
  while (maze[i] != NULL)
    {
      j = l = 0;
      while (maze[i][j] != '\0')
	{
	  if (maze[i][j] == 'o')
	    my_put_square(l, k, sfMagenta, framebuf, size);
	  else if (i == 0 && j == 0)
	    my_put_square(l, k, sfGreen, framebuf, size);
	  else if (maze[i + 1] == NULL && maze[i][j + 1] == '\0')
	    my_put_square(l, k, sfRed, framebuf, size);
	  else if (maze[i][j] == '-')
	    my_put_square(l, k, sfCyan, framebuf, size);
	  else if (maze[i][j] == '*')
	    my_put_square(l, k, sfWhite, framebuf, size);
	  else
	    my_put_square(l, k, sfBlue, framebuf, size);
	  l += size + 1;
	  j++;
	}
      i++;
      k += size + 1;
    }
}

char		**keep_window_open(sfRenderWindow *window, sfTexture *texture, sfSprite *sprite,
				   t_my_framebuffer *buffer, char **maze, t_cell *cells, int size)
{
  size_t	i;
  sfEvent	event;

  i = 0;
  while (sfRenderWindow_isOpen(window))
    {
      if (cells[i].x != -1)
	{
	  sfRenderWindow_clear(window, sfBlack);
	  maze[cells[i].y][cells[i].x] = '*';
	  if (cells[i].x == 0 && cells[i].y == 0)
	    my_put_square(cells[i].x * size + cells[i].x, cells[i].y * size + cells[i].y, sfGreen, buffer, size + 1);
	  else
	    my_put_square(cells[i].x * size + cells[i].x, cells[i].y * size + cells[i].y, sfWhite, buffer, size + 1);
	  if (cells[i].link == 0)
	    {
	      maze[cells[i].y - 1][cells[i].x] = '*';
	      my_put_square(cells[i].x * size + cells[i].x, (cells[i].y - 1) * size + cells[i].y, sfWhite, buffer, size + 1);
	    }
	  else if (cells[i].link == 1)
	    {
	      maze[cells[i].y][cells[i].x - 1] = '*';
	      my_put_square((cells[i].x - 1) * size + cells[i].x, cells[i].y * size + cells[i].y, sfWhite, buffer, size + 1);
	    }
	  if (cells[i + 1].x == -1 && maze[cells[i].y + 1] != NULL &&
	      maze[cells[i].y][cells[i].x + 1] != '\0')
	    {
	      srand(time(NULL));
	      if (rand() % 2 == 0)
		{
		  maze[cells[i].y + 1][cells[i].x] = '*';
		  my_put_square(cells[i].x * size + cells[i].x, (cells[i].y + 1) * size + (cells[i].y + 1), sfWhite, buffer, size);
		}
	      else
		{
		  maze[cells[i].y][cells[i].x + 1] = '*';
                  my_put_square((cells[i].x + 1) * size + (cells[i].x + 1), cells[i].y * size + cells[i].y, sfWhite, buffer, size);
		}
	    }
	  i++;
//	  draw_maze(maze, buffer, size);
	  sfTexture_updateFromPixels(texture, buffer->pixels,
				     buffer->width, buffer->height, 0, 0);
	}
      while (sfRenderWindow_pollEvent(window, &event))
	{
	  if (event.type == sfEvtKeyPressed && event.key.code == sfKeyEscape)
	    sfRenderWindow_close(window);
	  if (event.type == sfEvtClosed)
	    sfRenderWindow_close(window);
	}
      sfRenderWindow_clear(window, sfBlack);
      sfRenderWindow_drawSprite(window, sprite, NULL);
      sfRenderWindow_display(window);
    }
  return (maze);
}

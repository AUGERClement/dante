/*
** my_framebuffer_create.c for emacs in /home/delphine.godet/wireframe/src
**
** Made by delphine godet
** Login   <delphine.godet@epitech.net>
**
** Started on  Fri Nov 18 19:35:59 2016 delphine godet
** Last update Sat May 13 23:39:15 2017 Delphine Godet
*/

#include <stdio.h>
#include <stdlib.h>
#include <SFML/Graphics.h>

typedef struct  s_my_framebuffer
{
  sfUint8       *pixels;
  int           width;
  int           height;
}               t_my_framebuffer;

t_my_framebuffer        *my_framebuffer_create(sfVideoMode mode)
{
  t_my_framebuffer      *framebuffer;
  unsigned int          i;

  if ((framebuffer = malloc(sizeof(t_my_framebuffer))) == NULL)
    return (NULL);
  framebuffer->width = mode.width;
  framebuffer->height = mode.height;
  framebuffer->pixels = malloc(mode.width *
			       mode.height * 4 *
			       sizeof(framebuffer->pixels));
  if (framebuffer->pixels == NULL)
    return (NULL);
  i = 0;
  while (i < mode.width * mode.height * 4)
    {
      framebuffer->pixels[i] = 0;
      i = i + 1;
    }
  return (framebuffer);
}
